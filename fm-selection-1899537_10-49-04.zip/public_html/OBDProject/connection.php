<?php
ini_set('display_errors', 1);
$link = mysqli_connect('sdb-59.hosting.stackcp.net', 'obdcode-35303233cdc5', 'LT3y.Qh6&W~b','obdcode-35303233cdc5');

if (mysqli_connect_error()) {
    die('Errore di connessione al database');
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $code = mysqli_real_escape_string($link, $_POST['code']);

    $query = "SELECT `Description` FROM `editors` WHERE `Code` = '$code'";
    $result = mysqli_query($link, $query);

    if (!$result) {
        die('Errore nella query: ' . mysqli_error($link));
    }

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $message = "Your fault code " . $code . " is " . $row['Description'];
    } else {
        $message = "Codice non trovato";
    }

    mysqli_free_result($result);
    mysqli_close($link);
}
?>